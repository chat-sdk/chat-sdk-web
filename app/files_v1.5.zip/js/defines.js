/**
 * Created by benjaminsmiley-andrews on 15/05/2014.
 */

var CF_ANIMATION_DURATION = 300;


var CF_LOGIN_BOX = "#cf-login-box";

var CF_LOGIN_BOX_TITLE = "#cf-login-header";

var CF_PROFILE_SETTINGS_BOX = "#cf-profile-settings-box";


var CF_APP_MODE_LOGIN = 1;
var CF_APP_MODE_MAIN = 2;
var CF_APP_MODE_PROFILE_SETTINGS = 3;

var USERS_PATH = 'users';
var FIREBASE_PATH = '"https://messg.firebaseio.com/"';